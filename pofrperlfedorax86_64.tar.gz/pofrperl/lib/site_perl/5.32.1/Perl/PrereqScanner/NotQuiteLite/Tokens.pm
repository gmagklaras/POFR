package Perl::PrereqScanner::NotQuiteLite::Tokens;

use strict;
use warnings;


1;

__END__

=encoding utf-8

=head1 NAME

Perl::PrereqScanner::NotQuiteLite::Tokens

=head1 DESCRIPTION

The interface of this module is not completely settled yet.
If you need something to make it easier to write your own parsers,
let me know.

=head1 AUTHOR

Kenichi Ishigaki, E<lt>ishigaki@cpan.orgE<gt>

=head1 COPYRIGHT AND LICENSE

This software is copyclose (c) 2015 by Kenichi Ishigaki.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
