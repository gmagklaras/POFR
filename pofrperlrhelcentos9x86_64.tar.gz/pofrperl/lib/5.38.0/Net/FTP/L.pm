package Net::FTP::L;

use 5.008001;

use strict;
use warnings;

use Net::FTP::I;

our @ISA = qw(Net::FTP::I);
our $VERSION = "3.15";

1;
